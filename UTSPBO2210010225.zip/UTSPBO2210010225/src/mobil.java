public class mobil extends motor {

    // kontraktor
    mobil (String merk, String warna, int harga, int diskon) {
       super(merk, warna, harga, diskon);
    }

    // mutator
    @Override
    void setdiskon(int benda) {
        harga = harga - benda;
    }

    // accesor
    @Override
    int getharga() {
        return harga;
    }
}

