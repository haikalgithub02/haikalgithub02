public class motor extends diskon{
    protected String merk;
    protected String warna;
    protected int harga;
    protected int diskon;

    // kontraktor
    motor(String merk, String warna, int diskon, int harga) {
        this.merk = merk;
        this.warna = warna;
        this.harga = harga;
        this.diskon = diskon;
    }

    // mutator
    void setdiskon(int barang) {
        harga = harga - barang;
    }

    // accesor
    int getharga() {
        return harga;
    }
}

