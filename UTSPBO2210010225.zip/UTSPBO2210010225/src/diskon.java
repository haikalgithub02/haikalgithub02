
public class diskon {
       public static void main (String[]args){
        motor barang = new motor ("honda","biru",30000,100000);
        
        
        
        System.out.println("merk : " + barang.merk);
        System.out.println("warna : " + barang.warna);
        System.out.println("mendapatkan diskon : " + barang.diskon);
        System.out.println("harga : " + barang.harga);
        barang.setdiskon(20000);
        System.out.println("harga barang :" + barang.getharga());
        
        
        
        System.out.println();
        mobil benda = new mobil ("honda","biru",60000,500000);
        System.out.println("merk : " + benda.merk);
        System.out.println("warna : " + benda.warna);
        System.out.println(benda.diskon + "mendapatkan diskon : ");
        System.out.println("harga : " + benda.harga);
        benda.setdiskon(30000);
        System.out.println("harga barang :" + benda.getharga());
      
    }
}


